package com.morrisons.sma.pojo.service.StockInfoServicePOJO;

public class StockInfo_UnitEquivalentPrice {

}
